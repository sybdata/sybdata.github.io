<html>
<body>
<p>Waehlen Sie aus, welcher Datensatz geaendert werden soll:</p>
<form action = "ch_single_2.php" method = "post">
<?php
   $user = "tux";
	$servername = "127.0.0.1";
	$password = "tux1234";
	$dbname = "patienten";

//Verbindung zur Datenbank aufbauen
$con = new mysqli($servername, $user, $password, $dbname);


if ($con->connect_error) {
	die("Connect failed: " . $con->connect_error);
}
echo "Verbindung hergestellt<br /><br />";
  
   //Datenbank auswaehlen
   mysqli_select_db($con, "patienten");
   //Alle Daten aus der Tabelle abfragen
   $res = mysqli_query($con, "select * from patient");

   // Tabellenbeginn
   echo "<table border='1'>";

   // Ueberschrift
   echo "<tr> <td>Auswahl</td> <td>Vorname</td>";
   echo "<td>Nachname</td> <td>Geburtsdatum</td>";
   echo "<td>Zimmernummer</td> </tr>";

   while ($dsatz = mysqli_fetch_assoc($res))
   {
      echo "<tr>";
      echo "<td><input type='radio' name='auswahl'";
      echo " value='" . $dsatz["p_id"] . "' /></td>";
      echo "<td>" . $dsatz["vorname"] . "</td>";
      echo "<td>" . $dsatz["nachname"] . "</td>";
      echo "<td>" . $dsatz["geburtsdatum"] . "</td>";
      echo "<td>" . $dsatz["z_id"] . "</td>";
      echo "</tr>";
   }

   // Tabellenende
   echo "</table>";
   
   mysqli_close($con);
?>
<p><input type="submit" value="Datensatz anzeigen" /></p>
<form action = "db_einzel_b.php" method = "post">
</form>
<p>
<input type="button" value="Startseite" onclick="location.href='index.html'" /><br><br><br>
</p>
</body>
</html>
