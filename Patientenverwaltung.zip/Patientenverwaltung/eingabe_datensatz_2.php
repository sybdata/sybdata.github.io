<html>
<head>
<title>Abfrage DB Patienten</title>
</head>
<body>

<?php
	$user = "tux";
	$servername = "127.0.0.1";
	$password = "tux1234";
	$dbname = "patienten";

//Verbindung zur Datenbank aufbauen
$con = new mysqli($servername, $user, $password, $dbname);


if ($con->connect_error) {
	die("Connect failed: " . $con->connect_error);
}
echo "Verbindung hergestellt<br /><br />";

//SQL-Kommando formulieren
//
$sql = "INSERT INTO patient"
	. "(vorname,nachname,geburtsdatum,z_id) VALUES "
	. "('" . $_POST["vor"] . "', "
	. "'" . $_POST["nach"] . "', "
	. "'" . $_POST["geb"] . "', "
	. "'" . $_POST["zim"] . "')";


// Daten an Server senden
//
mysqli_query($con, $sql);
//
// Anzahl der Datensaetze
$num = mysqli_affected_rows($con);
if ($num>0) {
echo "<p><font color='#00aa00'>";
echo "Es wurde ein Datensatz hinzugefuegt";
echo "</font></p>";
}
else {
echo "<p><font color=''#FF0000>";
echo "ES IST EIN FEHLER AUFGETRETEN ";
echo "ACHTUNG:Es wurde KEIN Datensatz hinzugefuegt";
echo "</font></p>"; 
}

//Datenabfrage ausfueren
$sql = "SELECT vorname,nachname,z_id FROM patient";
$sql .= " WHERE vorname like '" . $_POST["vor"] . "%'" 
	. " AND nachname like '" . $_POST["nach"] . "%'";

// Anfrage an Server senden
$res = mysqli_query($con, $sql);

// Anzahl der Datensaetze
$num = mysqli_num_rows($res);
if ($num==0) echo "Keine passenden Datensaetze gefunden";
//Tabellenbeginn
echo "<table border='1'>";

//Ueberschrift
echo "<tr> <td>Vorname</td> <td>Nachname</td>";
echo "<td>Zimmernummer</td></tr>";
while($dsatz = mysqli_fetch_assoc($res))
{
	echo "<tr>";
	echo "<td>" . $dsatz["vorname"] ."</td> ";
	echo "<td>" . $dsatz["nachname"] . "</td>";
	echo "<td>" . $dsatz["z_id"] ."</td>";
	echo "</tr>";
}

//Tabellenende
echo "</table>";


// Verbindung schliessen
mysqli_close($con);
 ?>
 <p>
<input type="button" value="Zurueck zum Formular" onclick="location.href='formular_eingabe_patient.html'" />
</p>
 <p>
<input type="button" value="Startseite" onclick="location.href='index.html'" />
</p>
</body>
</html>
