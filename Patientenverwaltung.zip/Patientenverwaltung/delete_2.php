<html>
<body>
<?php
if (isset($_POST["auswahl"]))
{
	$user = "tux";
	$servername = "127.0.0.1";
	$password = "tux1234";
	$dbname = "patienten";

//Verbindung zur Datenbank aufbauen
$con = new mysqli($servername, $user, $password, $dbname);

if ($con->connect_error) {
	die("Connect failed: " . $con->connect_error);
}
   //Datenbank auswaehlen
   mysqli_select_db($con, "patienten");

   $sql = "delete from patient where"
     . " p_id = " . $_POST["auswahl"];

   mysqli_query($con, $sql);

   $num = mysqli_affected_rows($con);
   if ($num>0)
      echo "<p>Der Datensatz wurde geloescht</p>";
   else
      echo "<p>ACHTUNG:Der Datensatz wurde NICHT geloescht</p>";

   mysqli_close($con);
}
else
   echo "<p>Es wurde kein Datensatz ausgewaehlt</p>";
?>
<input type="button" value="Zurueck zur Auswahl" onclick="location.href='delete_1.php'" /><br><br><br>
<p>
<input type="button" value="Startseite" onclick="location.href='index.html'" /><br><br><br>
</p>
</body>
</html>
