<html>
<body>
<p>Waehlen Sie aus, welcher Datensatz geloescht werden soll:</p>
<form action = "delete_2.php" method = "post">

<?php
  $user = "tux";
	$servername = "127.0.0.1";
	$password = "tux1234";
	$dbname = "patienten";

//Verbindung zur Datenbank aufbauen
$con = new mysqli($servername, $user, $password, $dbname);


if ($con->connect_error) {
	die("Connect failed: " . $con->connect_error);
}
//Datenbank auswaehlen
   mysqli_select_db($con, "firma");

   $res = mysqli_query($con, "select * from patient");
   $num = mysqli_num_rows($res);

   // Tabellenbeginn
   echo "<table border='1'>";

   // Ueberschrift
   echo "<tr> <td>Auswahl</td> <td>Vorname</td>";
   echo "<td>Nachnamename</td> <td>Geburtsdatum</td>";
   echo "<td>Zimmernummer</td>";

   while ($dsatz = mysqli_fetch_assoc($res))
   {
      echo "<tr>";
      echo "<td><input type='radio' name='auswahl'";
      echo " value='" . $dsatz["p_id"] . "'></td>";
      echo "<td>" . $dsatz["vorname"] . "</td>";
      echo "<td>" . $dsatz["nachname"] . "</td>";
      echo "<td>" . $dsatz["geburtsdatum"] . "</td>";
      echo "<td>" . $dsatz["z_id"] . "</td>";
      echo "</tr>";
   }

   // Tabellenende
   echo "</table>";
   
   mysqli_close($con);
?>
<p><input type="submit" value="Datensatz loeschen" /></p>
</form>
<p>
<input type="button" value="Startseite" onclick="location.href='index.html'" /><br><br><br>
</p>
</body>
</html>
