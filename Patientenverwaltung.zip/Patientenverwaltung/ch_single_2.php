<html>
<body>
<?php
if (isset($_POST["auswahl"]))
{
    $user = "tux";
	$servername = "127.0.0.1";
	$password = "tux1234";
	$dbname = "patienten";

//Verbindung zur Datenbank aufbauen
$con = new mysqli($servername, $user, $password, $dbname);


if ($con->connect_error) {
	die("Connect failed: " . $con->connect_error);
}
echo "Verbindung hergestellt<br /><br />";   
   //Datenbank auswaehlen
   mysqli_select_db($con, "patienten");

   $sql = "select * from patient where p_id = " . $_POST["auswahl"];
   $res = mysqli_query($con, $sql);
   $dsatz = mysqli_fetch_assoc($res);

   echo "<p>Fuehren Sie die Aenderungen durch,<br />";
   echo "betaetigen Sie anschliessend den Button</p>";
   echo "<form action = 'ch_single_3.php' method = 'post'>";

   echo "<p><input name='vn' value='" . $dsatz["vorname"] . "' /> Vorname</p>";
   echo "<p><input name='nn' value='" . $dsatz["nachname"] . "' /> Nachname</p>";
   echo "<p><input name='gd' value='" . $dsatz["geburtsdatum"] . "' /> Geburtsdatum</p>";
   echo "<p><input name='zn' value='" . $dsatz["z_id"] . "' /> Zimmernummer</p>";
   echo "<input type='hidden' name='oripn' value='" . $_POST["auswahl"] . "' />";
   echo "<p><input type='submit' value='Aenderungen in Datenbank speichern' />";
   echo " <input type='reset' value='Zuruecksetzen'/></p>";
   echo "</form>";
   
   mysqli_close($con);
}
else
   echo "<p>Es wurde kein Datensatz ausgewaehlt</p>";
?>
<p>
<input type="button" value="Zurueck zur Auswahl" onclick="location.href='ch_single_1.php'" /><br><br><br>
</p>
<p>
<input type="button" value="Startseite" onclick="location.href='index.html'" /><br><br><br>
</p>
</body>
</html>
