<html>
<body>
<?php
    $user = "tux";
	$servername = "127.0.0.1";
	$password = "tux1234";
	$dbname = "patienten";

//Verbindung zur Datenbank aufbauen
$con = new mysqli($servername, $user, $password, $dbname);

//Check Connect
if ($con->connect_error) {
	die("Connect failed: " . $con->connect_error);
}
echo "Verbindung hergestellt<br /><br />";
//Datenbank auswaehlen   
   mysqli_select_db($con, "patienten");
   
//SQL Statement formulieren
   $sql = "update patient set"
     . " vorname = '" . $_POST["vn"] . "',"
     . " nachname = '" . $_POST["nn"] . "',"
     . " geburtsdatum = '" . $_POST["gd"] . "',"
     . " z_id = '" . $_POST["zn"] . "'"
     . "where p_id = " .$_POST["oripn"];
  mysqli_query($con, $sql);

//Datenbank-Antwort
   $num = mysqli_affected_rows($con);
   if ($num>0)
      echo "<p>Der Datensatz wurde geaendert</p>";
   else
      echo "<p>Der Datensatz wurde nicht geaendert</p>";
	  
   mysqli_close($con);
?>
<input type="button" value="Zurueck zur Auswahl" onclick="location.href='ch_single_1.php'" />
<p>
<input type="button" value="Startseite" onclick="location.href='index.html'" /><br><br><br>
</p>
</body>
</html>
