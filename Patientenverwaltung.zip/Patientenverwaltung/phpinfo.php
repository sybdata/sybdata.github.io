<?php phpinfo();?>
